import os
import sys
import random
import numpy as np
import cv2
import pickle
from sklearn.model_selection import StratifiedKFold
import itertools
import tensorflow as tf

RANDOM_STATE=0
np.random.seed(RANDOM_STATE)

def _bytes_feature(value):
    if isinstance(value, type(tf.constant(0))): # if value ist tensor
        value = value.numpy() # get value of tensor
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))

def _int64_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=[value]))

def serialize_array(array):
    array = tf.io.serialize_tensor(array)
    return array

def save_tfrecords(data, label, desfile):
    with tf.io.TFRecordWriter(desfile) as writer:
        for i in range(len(data)):
            
            feature = {
                "data":_bytes_feature(serialize_array(data[i])),
                "label":_int64_feature(label[i])
            }
            example = tf.train.Example(features=tf.train.Features(feature=feature))
            serialized = example.SerializeToString()
            writer.write(serialized)

def _parse_tfr_element(element):
    parse_dic = {
        'data': tf.io.FixedLenFeature([], tf.string),
        'label': tf.io.FixedLenFeature([], tf.int64)
    }
    example_message = tf.io.parse_single_example(element, parse_dic)
    
    d_feature = example_message['data'] # get byte string
    data = tf.io.parse_tensor(d_feature, out_type=tf.uint8)
    return data, example_message['label']


def test_tfrecords(filename):

    tfr_dataset = tf.data.TFRecordDataset(filename)
    for serialized_instance in tfr_dataset:
        print(serialized_instance) # print serialized example messages
        
    dataset = tfr_dataset.map(_parse_tfr_element)
    for instance in dataset:
        print(instance)
    
#A method that generates a train-test split
def gen_records(source_folder, n_classes):

    # Load in files for images, labels, and splits
    source = source_folder + str(n_classes) + 'Classes/'
    all_images = np.load(source + 'image_set.npy').astype(np.uint8)
    all_labels = np.load(source + 'label_set.npy')
    # Do so global preprocessing for images and create 3 channel images
    all_images_c = np.concatenate((all_images, all_images, all_images), axis=-1)
    
    # Divide images and labels to produce 25 groupings
    final_images = list()
    final_labels = list()
    final_images_c = list()
    split_dicts = list()
    data_len = all_labels.shape[0]
    kfold = StratifiedKFold(n_splits=25, random_state=RANDOM_STATE)
    for i, (_, t_inds) in enumerate(kfold.split(all_images, all_labels)):
    
        final_images.append(all_images[t_inds])
        final_images_c.append(all_images_c[t_inds])
        final_labels.append(all_labels[t_inds])

        # Store information on lengths of different sets, the corresponding tfrecord
        # indices, and the labels for the test dataset
        if i % 5 == 4:
            split_dict = dict()
            split_dict['test_labels'] = np.concatenate(final_labels[-5:])
            split_dict['test_len'] = len(split_dict['test_labels'])
            split_dict['train_len'] = int(0.8 * (data_len - split_dict['test_len']))
            split_dict['val_len'] = int(0.2 * (data_len - split_dict['test_len']))
            split_dict['test_indices'] = list(range(i-4, i+1))
            v_ind =  (i + 1) % 25
            split_dict['val_indices'] = list(range(v_ind, v_ind+4))
            train_indices = set(range(25)).difference(split_dict['test_indices'])
            train_indices = train_indices.difference(split_dict['val_indices'])
            split_dict['train_indices'] = list(train_indices)
            
            split_dicts.append(split_dict)

    # Write TFRecords to file:
    dest_folder1 = source + 'Records_1C/'
    dest_folder2 = source + 'Records_3C/'
    dest_folder3 = source + 'Split_Info/'
    
    if not os.path.exists(dest_folder1):
        os.makedirs(dest_folder1)
    if not os.path.exists(dest_folder2):
        os.makedirs(dest_folder2)
    if not os.path.exists(dest_folder3):
        os.makedirs(dest_folder3)
        
    for ind in range(len(final_labels)):
        dest_file1 = dest_folder1 + 'tfrec_' + str(ind)
        save_tfrecords(final_images[ind], final_labels[ind], dest_file1)
        
        dest_file2 = dest_folder2 + 'tfrec_' + str(ind)
        save_tfrecords(final_images_c[ind], final_labels[ind], dest_file2)

    for i, split_dict in enumerate(split_dicts):
        with open(dest_folder3 + 's_dict_' + str(i), 'wb+') as outfile:
            pickle.dump(split_dict, outfile)
        
def main():
    # Generate the TFRecords
    source_folder = './Data/'
    n_classes = 5
    gen_records(source_folder, n_classes)


def test():
    path = './Data/4Classes/Records_1C/data1.tfrecords'
    test_tfrecords(path)

    
    '''
    for im_features in data:
        raw_image = im_features[0]['data'].numpy()
        raw_label = im_features[0]['label']
    print(raw_image)
    print(raw_image.shape)
    print(raw_label)
    '''
if __name__ == '__main__':
    main()
