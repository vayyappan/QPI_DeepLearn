# Copyright 2019 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Trains a Keras model to predict income bracket from other Census data."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import os

from . import model
from . import util

import numpy as np
import tensorflow as tf
from tensorflow.keras.callbacks import TensorBoard, ModelCheckpoint, EarlyStopping
from sklearn.metrics import confusion_matrix
from tensorflow.python.lib.io import file_io
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import pickle

BATCH_SIZE=32

def get_args():
    """Argument parser.

    Returns:
      Dictionary of arguments.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--job-dir',
        type=str,
        required=True,
        help='local or GCS location for writing checkpoints and exporting '
             'models')
    parser.add_argument(
        '--num-epochs',
        type=int,
        default=25,
        help='number of times to go through the data, default=25')
    parser.add_argument(
        '--num-classes',
        type=int,
        default=3,
        help='the number of classes, default=5')
    parser.add_argument(
        '--drop-frac',
        type=float,
        default=0.2,
        help='the dropout rate for the networks, default=0.2')
    parser.add_argument(
        '--learning-rate',
        default=.01,
        type=float,
        help='learning rate for gradient descent, default=.01')
    parser.add_argument(
        '--split-indices',
        default=0,
        type=int,
        help='the set of indices to use to produce the train-test split, default=0')
    parser.add_argument(
        '--model-type',
        default=None,
        type=str,
        help='the model architecture to use, default=None')
    parser.add_argument(
        '--train-local',
        default=1,
        type=int,
        help='1 if we are to train the model locally or 0 if on cloud, default=1')
    parser.add_argument(
        '--verbosity',
        choices=['DEBUG', 'ERROR', 'FATAL', 'INFO', 'WARN'],
        default='INFO')
    args, _ = parser.parse_known_args()
    return args


def train_and_evaluate(args):
    """Trains and evaluates the Keras model.

v    Uses the Keras model defined in model.py and trains on data loaded and
    preprocessed in util.py. Saves the trained model in TensorFlow SavedModel
    format to the path defined in part by the --job-dir argument.

    Args:
      args: dictionary of arguments - see get_args() for details
    """

    pretrained=False
    n_channels = 1
    if args.model_type == 'resnet':
        pretrained = True
        n_channels = 3

    im_shape=(875, 1167)
    if args.num_classes == 4: 
        im_shape=(32, 32)
    
    split_info = util.load_split_info(args.split_indices,
                                 args.train_local,
                                 args.num_classes)
        
    train_recfiles = util.get_tfrecord_files(args.num_classes,
                                             split_info['train_indices'],
                                             args.train_local)
    
    val_recfiles = util.get_tfrecord_files(args.num_classes,
                                           split_info['val_indices'],
                                           args.train_local)

    train_dataset = util.create_dataset(train_recfiles,
                                        args.num_classes,
                                        im_shape,
                                        n_channels,
                                        BATCH_SIZE)
    val_dataset = util.create_dataset(val_recfiles,
                                      args.num_classes,
                                      im_shape,
                                      n_channels,
                                      BATCH_SIZE)
    

    # dimensions
    num_train_examples = split_info['train_len']
    num_val_examples = split_info['val_len']

    # Create the Keras Model
    if args.model_type == 'resnet':
        keras_model = model.create_resnet2(
            num_classes=args.num_classes,
            im_shape=im_shape,
            lr=args.learning_rate,
            drop_frac=args.drop_frac)
    elif args.model_type == 'smallconv':
        keras_model = model.create_conv_small(
            num_classes=args.num_classes,
            im_shape=im_shape,
            lr=args.learning_rate,
            drop_frac=args.drop_frac)
        
    elif args.model_type is None:
        exit('No model type has been selected')
    else:
        exit('Invalid model type')

    for lay in keras_model.layers:
        print(lay.name, lay.trainable)
    # Setup TensorBoard callbacks
    tensorboard_cb = TensorBoard(
        os.path.join(args.job_dir, 'keras_tensorboard'),
        histogram_freq=1)

    es = EarlyStopping(
        monitor='val_loss',
        patience=3)

    # Train model
    history = keras_model.fit(
        train_dataset,
        steps_per_epoch=int(num_train_examples / BATCH_SIZE),
        epochs=args.num_epochs,
        validation_data=val_dataset,
        validation_steps=int(num_val_examples / BATCH_SIZE),
        verbose=1,
        callbacks=[tensorboard_cb, util.MyMetricCallback(), es])
    
    # Make and save predictions
    test_y = split_info['test_labels']
    num_test_examples = split_info['test_len']

    
    test_recfiles = util.get_tfrecord_files(args.num_classes,
                                            split_info['test_indices'],
                                            args.train_local)
    
    test_dataset = util.create_dataset_pred(test_recfiles,
                                            args.num_classes,
                                            im_shape,
                                            n_channels,
                                            BATCH_SIZE)

    

    y_pred = keras_model.predict(test_dataset,
                                 steps=np.ceil(num_test_examples * 1.0/BATCH_SIZE))
    y_pred = np.argmax(y_pred, axis=1)
    
    c_mat = confusion_matrix(test_y, y_pred)
    
    # Save model and relevant files
    export_path = os.path.join(args.job_dir, 'keras_export')
    keras_model.save(export_path, save_format='tf')
    print('Model exported to: {}'.format(export_path))

    dest = os.path.join(args.job_dir, 'predictions.txt')
    with file_io.FileIO(dest, 'w') as outfile:
        np.savetxt(outfile, y_pred, fmt='%d')

    dest = os.path.join(args.job_dir, 'confusion.txt')
    with file_io.FileIO(dest, 'w') as outfile:
        np.savetxt(outfile, c_mat, fmt='%d')

    
    dest = os.path.join(args.job_dir, 'history.pkl')
    with file_io.FileIO(dest, mode='wb') as outfile:
        pickle.dump(history.history, outfile)
        
    dest = os.path.join(args.job_dir, 'input_params.txt')    
    with file_io.FileIO(dest, 'w') as outfile:
        outfile.write('model_type\t' + str(args.model_type) + '\n')
        outfile.write('num_classes\t' + str(args.num_classes) + '\n')
        outfile.write('num_epochs\t' + str(args.num_epochs) + '\n')
        outfile.write('split_indices\t' + str(args.split_indices) + '\n')
        if not pretrained:
            outfile.write('drop_frac\t' + str(args.drop_frac) + '\n')
        outfile.write('learning_rate\t' + str(args.learning_rate) + '\n')

if __name__ == '__main__':
    args = get_args()
    tf.compat.v1.logging.set_verbosity(args.verbosity)
    train_and_evaluate(args)
