from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
from six.moves import urllib
import tempfile

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.python.lib.io import file_io
import functools
import pickle
from datetime import datetime

SHUFFLE_BUFFER = 128
LOCAL_DATA_DIR = '/home/alex/deep_leuk/Data/'
CLOUD_DATA_DIR = 'gs://dl_qpi/Data/'

class MyMetricCallback(tf.keras.callbacks.Callback):
    
    def on_epoch_end(self, epoch, logs=None):
        tf.summary.scalar('val_loss', logs['val_loss'], epoch)
        
        logdir = "logs/scalars/" + datetime.now().strftime("%Y%m%d-%H%M%S")
        file_writer = tf.summary.create_file_writer(logdir + "/metrics")
        file_writer.set_as_default()

def load_split_info(split_ind, train_local, n_classes):
    if train_local == 1:
        split_file = (LOCAL_DATA_DIR +
                     str(n_classes) +
                     'Classes/Split_Info/s_dict_' +
                     str(split_ind))
    else:
        split_file = (CLOUD_DATA_DIR +
                     str(n_classes) +
                     'Classes/Split_Info/s_dict_' +
                     str(split_ind))

    with file_io.FileIO(split_file, mode='rb') as infile:
        split_dict = pickle.load(infile)

    return split_dict
    
def _parse_function(element, n_classes, im_shape, n_channels):
    parse_dic = {
        'data': tf.io.FixedLenFeature([], tf.string),
        'label': tf.io.FixedLenFeature([], tf.int64)
    }
    example_message = tf.io.parse_single_example(element, parse_dic)
            
    d_feature = example_message['data']
    data = tf.io.parse_tensor(d_feature, out_type=tf.uint8)
    data = tf.reshape(data, [im_shape[0], im_shape[1], 1])
    data = tf.cast(data, tf.float32) / 255.0
    if n_channels == 3:
        data = tf.image.grayscale_to_rgb(data)
    label = tf.cast(example_message['label'], tf.int32)
    label = tf.one_hot(label, depth=n_classes)
    return data, label

def _parse_function_pred(element, n_classes, im_shape, n_channels):
    parse_dic = {
        'data': tf.io.FixedLenFeature([], tf.string),
        'label': tf.io.FixedLenFeature([], tf.int64)
    }
    example_message = tf.io.parse_single_example(element, parse_dic)
            
    d_feature = example_message['data']
    data = tf.io.parse_tensor(d_feature, out_type=tf.uint8)
    data = tf.reshape(data, [im_shape[0], im_shape[1], 1])
    data = tf.cast(data, tf.float32) / 255.0
    if n_channels == 3:
        data = tf.image.grayscale_to_rgb(data)
    return data

def get_tfrecord_files(n_classes, indices, train_local):

    if train_local == 1:
        file_path = (LOCAL_DATA_DIR +
                     str(n_classes) +
                     'Classes/Records_1C/tfrec_')
    else:
        file_path = (CLOUD_DATA_DIR +
                     str(n_classes) +
                     'Classes/Records_1C/tfrec_')

    tfrec_files = list()
    for ind in indices:
        tfrec_files.append(file_path + str(ind))
    return tfrec_files
        
def create_dataset(file_list, n_classes, im_shape, n_channels, batch_size):

    dataset = tf.data.Dataset.list_files(file_list)
    dataset = dataset.interleave(tf.data.TFRecordDataset,
                                 cycle_length=tf.data.experimental.AUTOTUNE,
                                 num_parallel_calls=tf.data.experimental.AUTOTUNE)
    parse_funct = functools.partial(_parse_function,
                                    n_classes=n_classes,
                                    im_shape=im_shape,
                                    n_channels=n_channels)
    dataset = dataset.map(parse_funct,
                          num_parallel_calls=tf.data.experimental.AUTOTUNE)
    dataset = dataset.cache()
    dataset = dataset.repeat()
    dataset = dataset.shuffle(128)
    dataset = dataset.batch(batch_size, drop_remainder=True)
    dataset = dataset.prefetch(tf.data.experimental.AUTOTUNE)

    return dataset

def create_dataset_pred(file_list, n_classes, im_shape, n_channels, batch_size):

    dataset = tf.data.TFRecordDataset(file_list)
    parse_funct = functools.partial(_parse_function_pred,
                                    n_classes=n_classes,
                                    im_shape=im_shape,
                                    n_channels=n_channels)
    dataset = dataset.map(parse_funct,
                          num_parallel_calls=tf.data.experimental.AUTOTUNE)
    dataset = dataset.cache()
    dataset = dataset.batch(batch_size, drop_remainder=False)
    dataset = dataset.prefetch(tf.data.experimental.AUTOTUNE)

    return dataset
