from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import tensorflow as tf
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Conv2D, Activation,BatchNormalization, MaxPooling2D, Dropout, Input, LeakyReLU, ReLU
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import Sequential
from tensorflow.keras.applications.vgg16 import VGG16
from tensorflow.keras.applications.resnet50 import ResNet50

def input_fn(features, labels, shuffle, num_epochs, batch_size):
    """Generates an input function to be used for model training.

    Args:
      features: numpy array of features used for training or inference
      labels: numpy array of labels for each example
      shuffle: boolean for whether to shuffle the data or not (set True for
        training, False for evaluation)
      num_epochs: number of epochs to provide the data for
      batch_size: batch size for training

    Returns:
      A tf.data.Dataset that can provide data to the Keras model for training or
        evaluation
    """
    if labels is None:
        inputs = features
    else:
        inputs = (features, labels)
    dataset = tf.data.Dataset.from_tensor_slices(inputs)

    if shuffle:
        dataset = dataset.shuffle(buffer_size=len(features))

    # We call repeat after shuffling, rather than before, to prevent separate
    # epochs from blending together.
    dataset = dataset.repeat(num_epochs)
    dataset = dataset.batch(batch_size)
    return dataset

#Standard convolutional neural network
def create_example(num_classes, im_shape, drop_frac=0.2, lr=0.01):
    
    filter_size = 8
    kernel = (3,3)
    pool = (2,2)
    
    model = Sequential()

    model.add(Conv2D(filter_size, kernel, padding = "same", input_shape = (im_shape[0], im_shape[1], 1)))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=pool))
    
    model.add(GlobalAveragePooling2D())
    model.add(Dense(64))
    model.add(Dropout(drop_frac))
    model.add(ReLU())
 
    model.add(Dense(num_classes, activation='softmax'))
        
    model.compile(optimizer=Adam(lr=lr), loss='categorical_crossentropy', metrics=['accuracy'])
    
    return model


# Build a pretrained resnet model
def create_resnet1(num_classes, im_shape, lr=0.01):

    base_model = ResNet50(include_top=False,
                          weights='imagenet',
                          input_shape=(im_shape[0], im_shape[1], 3)) 
    base_model.trainable=False
    model = Sequential()
    model.add(base_model)
    model.add(GlobalAveragePooling2D())
    model.add(Dense(num_classes, activation='softmax'))
    
    
    model.compile(optimizer=Adam(lr=lr), loss='categorical_crossentropy', metrics=['accuracy'])

    return model

# Build a pretrained resnet model
def create_resnet2(num_classes, im_shape, lr=0.01, drop_frac=0.25):

    base_model = ResNet50(include_top=False,
                          weights='imagenet',
                          input_shape=(im_shape[0], im_shape[1], 3)) 
    base_model.trainable=False
    model = Sequential()
    model.add(base_model)
    model.add(GlobalAveragePooling2D())
    model.add(Dropout(drop_frac))
    model.add(ReLU())
    model.add(Dense(num_classes, activation='softmax'))
    
    
    model.compile(optimizer=Adam(lr=lr), loss='categorical_crossentropy', metrics=['accuracy'])

    return model


# Build a pretrained resnet model
def create_resnet3(num_classes, im_shape, lr=0.01, drop_frac=0.25):

    base_model = ResNet50(include_top=False,
                          weights='imagenet',
                          input_shape=(im_shape[0], im_shape[1], 3)) 
    base_model.trainable=False

    for i, lay in enumerate(base_model.layers):
        if(i >= 165):
            lay.trainable = True
            
    model = Sequential()
    model.add(base_model)
    model.add(GlobalAveragePooling2D())
    model.add(Dropout(drop_frac))
    model.add(ReLU())
    model.add(Dense(num_classes, activation='softmax'))
    
    
    model.compile(optimizer=Adam(lr=lr), loss='categorical_crossentropy', metrics=['accuracy'])

    return model


#Standard convolutional neural network
def create_conv_small(num_classes, im_shape, drop_frac=0.2, lr=0.01):
    
    filter_size = 8
    kernel = (3,3)
    pool = (2,2)
    
    model = Sequential()

    model.add(Conv2D(filter_size, kernel, padding = "same", input_shape = (im_shape[0], im_shape[1], 1)))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=pool))
    
    model.add(Conv2D(filter_size * 2, kernel, padding= "same"))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=pool))
    
    model.add(GlobalAveragePooling2D())
    model.add(Dense(512))
    model.add(Dropout(drop_frac))
    model.add(Dense(256))
    model.add(Dropout(drop_frac))
    model.add(ReLU())

    model.add(Dense(num_classes, activation='softmax'))
        
    model.compile(optimizer=Adam(lr=lr), loss='categorical_crossentropy', metrics=['accuracy'])
    
    return model

