#!/bin/bash

set -ev

echo "Training local ML model"

JOB_NAME="small_conv_c5r0s4"
BUCKET="gs://dl_qpi"
JOB_DIR="$BUCKET/small_conv_c5r0s4"


gcloud ai-platform jobs submit training $JOB_NAME \
		--package-path trainer/ \
		--module-name trainer.task \
		--region $REGION \
		--python-version 3.7 \
		--runtime-version 1.15 \
		--job-dir $JOB_DIR \
		--stream-logs \
        --config config_file.yaml 
