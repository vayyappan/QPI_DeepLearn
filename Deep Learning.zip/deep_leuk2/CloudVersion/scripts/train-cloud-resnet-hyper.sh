#!/bin/bash

set -ev

echo "Training local ML model"

JOB_NAME="resnet_lr_and_dropout_c5_r0_s0"
BUCKET="gs://dl_qpi"
JOB_DIR="$BUCKET/resnet_lr_and_dropout_c5_s0"


gcloud ai-platform jobs submit training $JOB_NAME \
	   --package-path trainer/ \
	   --module-name trainer.task \
	   --region $REGION \
	   --python-version 3.7 \
	   --runtime-version 2.1 \
	   --job-dir $JOB_DIR \
	   --stream-logs \
	   --config ./ConfigFiles/config_resnet_hyper2.yaml
