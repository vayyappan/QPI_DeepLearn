#!/bin/bash

set -ev

echo "Training local ML model"

JOB_NAME="sandbox_small_conv9"
BUCKET="gs://dl_qpi"
JOB_DIR="$BUCKET/sandbox_small_conv9"


gcloud ai-platform jobs submit training $JOB_NAME \
	   --package-path trainer/ \
	   --module-name trainer.task \
	   --region $REGION \
	   --python-version 3.7 \
	   --runtime-version 2.1 \
	   --job-dir $JOB_DIR \
	   --stream-logs \
	   --config ./ConfigFiles/config_smallconv_single.yaml
