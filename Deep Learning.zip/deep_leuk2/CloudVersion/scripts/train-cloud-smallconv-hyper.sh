#!/bin/bash

set -ev

echo "Training local ML model"

JOB_NAME="small_conv_c5r2s0"
BUCKET="gs://dl_qpi"
JOB_DIR="$BUCKET/small_conv_c5r2s0"


gcloud ai-platform jobs submit training $JOB_NAME \
	   --package-path trainer/ \
	   --module-name trainer.task \
	   --region $REGION \
	   --python-version 3.7 \
	   --runtime-version 2.1 \
	   --job-dir $JOB_DIR \
	   --stream-logs \
	   --config ./ConfigFiles/config_smallconv_hyper.yaml
