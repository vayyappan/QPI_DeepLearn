#!/bin/bash

set -ev

echo "Training local ML model"



PACKAGE_PATH=./trainer


gcloud ai-platform local train \
        --module-name trainer.task \
        --package-path trainer \
        --job-dir local-training-output
