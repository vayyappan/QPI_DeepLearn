function result = pts2img(Pl,P,Nx,Ny,RangeX,RangeY,h);

% function that generates an image of a point distribution
% according to the psf specified by h. 
% 
% INPUTS:
% Pl: point mass locations
% P: point mass weights
% RangeX: [a,b] range in the x dimension in which to assamble image
% RangeY: [a,b] same in y dimension
% h: 2D array specifying a point spread function



% make image grid
I = zeros(Ny,Nx);

% transfer these to pixel coordinates
N = length(P);
cm = repmat([RangeX(1);RangeY(1)],1,N);
resx = Nx/(RangeX(2)-RangeX(1));
resy = Ny/(RangeY(2)-RangeY(1));
rm = repmat([resx;resy],1,N);

%Pl2 = (Pl - cm).*rm;
Pl2 = Pl+6;

www = sub2ind(size(I),round(Pl2(2,:)),round(Pl2(1,:)));
%I(www) = P; %???? here is the error
for k= 1:length(www)
   I(www(k)) = I(www(k))+P(k); 
end

I = imfilter(I,h,'same');

result = I;
end
