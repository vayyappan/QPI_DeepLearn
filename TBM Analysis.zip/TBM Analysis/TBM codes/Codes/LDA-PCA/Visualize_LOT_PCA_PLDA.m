function []=Visualize_LOT_PCA_PLDA(LOT_coordinates,particle_weights,labels,data_name,alpha,percentage)
% This function calculated the PCA and pLDA in PCA space.
if nargin<3
    error('Not enough inputs!')
end
if nargin<4
    alpha=[];
    data_name='dataset';    
    percentage=.9;
end
if nargin<5 
    alpha=[];
    percentage=.9;
end
if nargin<6    
    percentage=.9;
end

M=300;%[M,N]=Size of each visualized image
N=300;

SD=4; %SD identifies the range of visualization in the dataset. For instance,
      %4 means the range [-4\sigma,4\sigma].
NS=8; %NS identifies the number of images to be visualized in the [-SD\sigma,SD\sigma],
      %in each PCA direction.

%Put the data in matrix form
for i=1:size(LOT_coordinates,2)
    Psi(:,i)=reshape((LOT_coordinates{i})',2*size(particle_weights,2),1);
end

Psi_mean=mean(Psi')'; %Get the data mean

Psi=Psi-repmat(Psi_mean,1,size(Psi,2)); %Make the data mean zero

[eigen_vectors,eigen_values]=PCA_LinearEmbedding(Psi);

eigen_vectors=real(eigen_vectors);

% Calculate the number of eigen_vectors that capture `percentage'%
% variations in the dataset.

for i=1:size(Psi,2)
    teig(i)=sum(eigen_values(1:i))/sum(eigen_values);
end

figure
% Plot the percentage variations captured versus the number of PCA
% directions and the cut off.
plot(100*teig,'linewidth',2)
grid on
title('PCA directions variation coverage','fontsize',20)
ylabel('Percentage of data set variation coverage','fontsize',20)
xlabel('Number of PCA directions','fontsize',20)
NPCA=find(teig>percentage,1,'first');%Number of PCA directions 
hold on
plot(NPCA*ones(1,101),0:100,'r','linewidth',2)

% Find standard deviation of the projected data on each mode of PCA and
% then set the range of visualization to be [-SD*std,+SD*std].
for j=1:NPCA
    lambda(j,:)=linspace(-SD*std(eigen_vectors(:,j)'*Psi),SD*std(eigen_vectors(:,j)'*Psi),NS);            
end
%Visualize the modes of variations.
Big=[];
for j=1:NPCA
    B=[];
    for i=1:NS
        im=Visualize_LOT(lambda(j,i)*eigen_vectors(:,j)+Psi_mean,particle_weights,M,N,2);                       
        B=[B;im];
    end
    Big=[Big,B];
end
figure
screenSize = get(0,'ScreenSize')
imshow(mat2gray(Big),'InitialMagnification',20)
brighten(-.5);
title({'Prominent modes of variation'; ['Capturing >%90 of variations in the ', data_name]},'fontsize',24)
iptsetpref('ImshowAxesVisible','on')
ylabel('$$(\sigma)$$','interpreter','latex','fontsize',24)
set(gca,'YTick',linspace(1,size(Big,1),5));
set(gca,'YTickLabel',{'-4','2','0','2','4'});
temp=round(size(Big,2)/(2*NPCA));
set(gca,'XTick',linspace(temp,size(Big,2)-temp,NPCA));
set(gca,'XTickLabel',{}); 
xlabel('Modes of variations','fontsize',20);
set(gca,'fontsize',24);
set(gcf,'PaperPositionMode','auto')

%% Calculate pLDA in PCA space
%  If \alpha is not provided calculate an optimum alpha
if isempty(alpha)
    Curveoption.low=.01;%Lower bound of alpha
    Curveoption.high=10;%Upper bound of alpha
    Curveoption.step=0.01;%step size of increasing alpha
    Curveoption.nPLDA=3;%The dimension of subspaces to be compared
    alpha=Calculate_Alpha(Psi,labels,eigen_vectors,Curveoption);
end
% Calculate the pLDA direction in the PCA space
[P_Vec,sigma]=PLDA_in_PCAspace(Psi,labels,size(Psi,2),alpha,eigen_vectors);
% Make sure that there is no complex values
P_Vec=real(P_Vec);
% Project the data on the PLDA directions
PLDA2=P_Vec'*(Psi);

%% Run the two sample Kolmogorov-Smirnov (KS) test for the populations of the 
%  projected data on each PLDA direction.

class=unique(labels)
for j=1:size(PLDA2,1)
    for i=1:length(class)
        dataclass{i,j}=PLDA2(j,labels==class(i));
    end
    [h,p(j,1)] = kstest2(dataclass{1,j},dataclass{2,j});
end

%Sort the PLDA direction according to the (KS) p-values.

[~,loc]=sort(p,'ascend');
p=p(loc,:);
P_Vec=P_Vec(:,loc);
PLDA2=P_Vec'*(Psi);

%Show the first sorted pLDA direction and data populations. 
clear ntemp
cmap = [1 0 0;0 0 1;0 1 0];
for j=1
    std_PLDA2=std(PLDA2(j,:));
    lambdaPLDA=linspace(-4*std_PLDA2,4*std_PLDA2,20);
    for i=1:length(class)
        ntemp(:,i)=hist(PLDA2(j,labels==class(i)),lambdaPLDA);
        ntemp(:,i)=ntemp(:,i)/sum(ntemp(:,i));
    end
end
figure
subplot(5,5,1:15)
B=bar(lambdaPLDA,ntemp);
set(gca,'XTick',linspace(-SD*std_PLDA2,SD*std_PLDA2,5))
set(gca,'XTickLabel',{})   
set(gca,'fontsize',24)
grid on
ch = get(B,'child');
lambdaPLDA=linspace(-SD*std_PLDA2,SD*std_PLDA2,NS);
colormap(cmap)
bigimage=[];
for i=1:length(lambdaPLDA)
    im=Visualize_LOT(lambdaPLDA(i)*P_Vec(:,1)+Psi_mean,particle_weights',M,N,2);
    if i~=1
        bigimage=[bigimage,mat2gray(im)];
    end
    tim=im;
end
subplot(5,5,[16:25]);
iptsetpref('ImshowAxesVisible','off')
imshow(bigimage);
title('$$  -{4\sigma} \hspace{1.4in} -{2\sigma}\hspace{1.4in} {0} \hspace{1.5in} {2\sigma} \hspace{1.5in} {4\sigma}$$','interpreter','latex','fontsize',20)
set(gca,'fontsize',20)
% for i=1:length(class)
%     set(ch{i},'facecolor',cmap(i,:))
% end
xlabel(['K-S p-value = ',num2str(p(1))],'fontsize',20);
% leg={'Class 1','Class 2'};           
% legend(leg,'fontsize',24);
% set(gcf,'PaperPositionMode','auto')