function img_array_out = imageInitialization(img_array, option)

% There are 3 steps for the this code to eliminate Translation, Scaling, and
% Orientations (T,S,O). 
% Input: 
% image_array: the 3D array of the 2D images with 3rd dimension corresponding
% to the image number; 
% option: corresponding to which steps (T,S,O) you want to do in this code.
% It is a number between 0 and 7. If you rewrite this number to binary
% form, it will be more clear. It corresponds to 3 binary digit, with first
% digit indicating whether to eliminate Translation, 2nd indicating whether
% to eliminate Scaling and 3rd indicating whether to eliminate Orientation.
% Eg. If you want to eliminate TSO, then put '111', therefore option=7, if
% you just want to eliminate TO, then put '101', therefore option=5; if
% eliminating TS, then put '110', therefore option=6;
% Output:
% img_array_out: the output of the 2D images which are registered to
% eliminate the un-interested variations


if option<8
    

if ~exist('option','var') % Default parameters of LDDMM
    flag_tran=1;
    flag_scale=1;
    flag_orient=1;
    flag_group=1;
else    % User inputed parameters
    flag_tran=bitget(option, 3);
    flag_scale=bitget(option, 2);
    flag_orient=bitget(option, 1);  
    flag_group=1;
end

% Centering the images such that the output objects are located at image center
if flag_tran==1
    disp('Centering to eliminate the translation factor. Please wait ...');
    img_array_centered = init_center(img_array);
    %save('GL_centered.mat','img_array_centered')
    img_array = img_array_centered;
end

% Rescale the images such that the output objects have the same number of
% pixels
if flag_scale==1
    % To eliminate the scaling factor
    disp('Rescaling images to make the foreground have same area. Please wait ...');
    img_array_scaled =  init_scaled(img_array);
    %save('GL-scaled.mat','img_array_scaled');
    img_array = img_array_scaled;
end

% Rotate the images such that the major axis are aligned verticlely
if flag_orient==1
    % MA align to eliminate orientation, images are rotated to have the 
    % same orientation through a principal axis (Hotteling) transform.
    [ny,nx,nz] = size(img_array);
    disp('Aligning images along one axis to eliminate the orientation. Please wait ...');
    for k=1:nz,   
        img = img_array(:,:,k);
        img_array_ma(:,:,k) = ma_align2d(img);
    end
    %save('GL-ma.mat','img_array_ma');
    img_array = img_array_ma;
end

if flag_group==1
    % Group registration: images are 'flipped' left to right, and up and
    % down for the group affine registration
    disp('Flipping images for group registration. Please wait ...');
    img_array_out = group_register2d_rigid(img_array);
else
    img_array_out = img_array;
end

else
    disp('Option value should vary between 0 and 7');
    img_array_out = [];
end