% Particle-based LOT calculation. This is the main code of particle-based
% LOT which loads a raw image dataset, initializes it (normalize, translate
% , and rotate), calculates the particle approximation for initialzed images
% , and finally, calculates the LOT embedding for the dataset. 
% 
% Written by Soheil Kolouri, 2013. 

clear;clc;close all
t_total=tic;

%% Adding essential paths to Matlab route

LDAPCApath = [pwd,'/Codes/LDA-PCA'];
Initializationpath = [pwd,'/Codes/ImageInit'];
LOTpath = [pwd,'/Codes/LinearEmbedding'];
Particlepath = [pwd,'/Codes/Particle'];
Datapath = [pwd,'/Data'];
path(path,Initializationpath);
path(path,LOTpath);
path(path,Particlepath);
path(path,LDAPCApath);
path(path,Datapath);

%% Load the raw image data set
Dataname='all_new_leukemia_TBM.mat';
%Dataname='liver_2cls_10cases.mat';
%Dataname='temp_Data.mat';
load(Dataname)
%The Data includes the following
%       imgs(1:Nx,1:Ny,1:K)   : K grayscale images
% 
%       labels(1:K)           : The corresponding labels for the images
%                               (cancerous vs. normal)
%       caseLabel(1:K)        : Patient's labels       

display('The dataset is loaded.');

[Nx,Ny,K]=size(imgs_initialized);%Get the size of the dataset

%% The following is the initialization step. In this step the images are 
%  centered, translated, and rotated to eliminate variations due to arbitrary
%  rotation,translation, and coordinate inversion. Please note that this
%  process may take a while.
t_init=tic;
imgs_initialized = imageInitialization(imgs_initialized, 5);
%We do not scale images to have the same area, however this can be done by 
%changing 5 to 7 in the line above. 
t_init=toc(t_init);

%% After the initialization step we approximate each image with Nmasses 
% particles. We note that the split and merge part of the code is disabled 
% for enhancing computation speed. 

Nmasses=500; % Number of particles to approximate images with. 500
display(['Approximated images with ',num2str(Nmasses),' particles'])
t_particle=tic;
tem_imgs=mean(imgs_initialized,3);% The average image is used as the template image.
[Pl,P] = particleApproximation(imgs_initialized, Nmasses);
% Particles are approximated and stored in P and Pl, which are the
% coordinates and the mass of the approximated particles for each image,
% respectively. 
[tem_Pl,tem_P] = img2pts_Lloyd(tem_imgs,Nmasses);
% The template image is also approximated with particles. tem_P and temp_Pl
% are coordinates and the mass of the approximated particles for the template
% image. 
t_particle=toc(t_particle);

%% Having the particles, we get the LOT embedding by finding mappings 
%  from the template to each image.

display('Calculating LOT from the particle approximated images')
t_LOT=tic;
[particle_weights,LOT_coordinates,var1] = LOT_LinearEmb(tem_P,tem_Pl,P,Pl); 
t_LOT=toc(t_LOT);

%% Visualizing the prominent and discriminat modes of variations in the
%  dataset using PCA and penalized LDA (pLDA).
%  Visualize the PCA modes
%  Visualize the discriminant modes.
Visualize_LOT_PCA_PLDA(LOT_coordinates,particle_weights,labels,'liver cells dataset');
t_total=toc(t_total);